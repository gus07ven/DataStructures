package BinaryTrees;

public class Nod {

		public int data;
		public Nod left;
		public Nod right;

		public Nod(int data) {
			this.data = data;
			this.left = null;
			this.right = null;
		}
	}
