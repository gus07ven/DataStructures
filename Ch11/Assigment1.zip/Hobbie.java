package Ch11;

import java.util.List;

public class Hobbie {
	
	private List<Book> book;
	private List<Movie> movie;
	
	public List<Book> getBook() {
		return book;
	}
	public void setBook(List<Book> book) {
		this.book = book;
	}
	public List<Movie> getMovie() {
		return movie;
	}
	public void setMovie(List<Movie> movie) {
		this.movie = movie;
	}
}
